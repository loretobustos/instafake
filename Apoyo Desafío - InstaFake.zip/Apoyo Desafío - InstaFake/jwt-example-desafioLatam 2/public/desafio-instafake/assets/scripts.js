let page = 1
const getPhotos = async (jwt) => {
    try {
        const response = await fetch(`http://localhost:3000/api/photos?page=${page}`, {
            method:'GET',
            headers: {
                Authorization: `Bearer ${jwt}`
            }
        })
        const {data} = await response.json()
        if (data) {
            appendPhotosToFeed(data)
            if(page === 1) {
                toggleFormAndFeed('js-form-wrapper','js-feed-wrapper')
            }
            page++
        }
       
    } catch (err) {
        localStorage.clear()
        console.error(`Error: ${err}`)
    } 
}

const postData = async (email, password) => {
    try {
        const response = await fetch('http://localhost:3000/api/login', {
            method:'POST',
            body: JSON.stringify({email:email,password:password})
        })
        const {token} = await response.json()
        localStorage.setItem('jwt-token',token)
        return token   
    } catch (err) {
        console.error(`Error: ${err}`)
    }
}

const toggleFormAndFeed = (form,table) => {
    $(`#${form}`).toggle()
    $(`#${table}`).toggle()
    $(`#js-logout-wrapper`).toggle()
}

const appendPhotosToFeed = (data) => {
    $.each(data, (i, item) => {
        let card = `<div class="card my-4">
                    <img src="${item.download_url}" class="card-img-top" alt="...">
                    <div class="card-body">
                        <p class="card-text">
                            Autor: ${item.author}
                        </p>
                    </div>
                </div>`
        $(`#js-feed-photos`).append(card);
    })
}

$('#js-form-login').submit(async (event) => {
    event.preventDefault()
    const email = document.getElementById('js-input-email').value
    const password = document.getElementById('js-input-password').value
    const JWT = await postData(email,password)
    getPhotos(JWT)
})

$('#js-btn-load-photos').on('click',(e) => {
    const token = localStorage.getItem('jwt-token')
    getPhotos(token)
})

$('#js-button-logout').on('click', (e) => {
    e.preventDefault()
    page = 1 
    localStorage.clear()
    toggleFormAndFeed('js-form-wrapper','js-feed-wrapper')
})

const init = async () => {
    const token = localStorage.getItem('jwt-token')
    if(token) {
        getPhotos(token)
    }
}

init()